#include<iostream>
#include<cstring>
#include<fstream>
#include<stdio.h>
#include<stdlib.h>
#include<ostream>
#define MAX 100
using namespace std;
struct NhanVien{
	char *HoTen;
	int NamSinh;
	char *QueQuan;
	double Luong;
};
struct Option{
	double MinValue, MaxValue;
};
void FreeNhanVien(NhanVien *pNV){
	delete []pNV;
}
char *NhanVienToString(NhanVien *pNV){
	char* result = new char[MAX];
	snprintf(result, MAX, "%dK", pNV->Luong);
	return result;
}
char* TrimText(char* &str){
	char* tmp = new char[MAX];
	int size = strlen(str);
    for(int i=0;i<size;i++){
    	str[i]=tolower(str[i]);
	}
	for(int i = 0; i<size;i++){
		for(int j =i+1; j<size;j++){
		if (str[i] == ' ')
        {
            str[i + 1] = toupper(str[i + 1]);
        }
        else
        {
            str[i] = tolower(str[i]);
        }
		}
	}
	tmp = str;
	return tmp;
}
void Load(char* path, NhanVien** &data, int &nCol, int &nRow){
	ifstream input;
	input.open(path);
	if(!input.is_open()){
		cout<<"\nMo file khong thanh cong! "<<endl;
		return;
	}
	for(int i=0;i<nCol;i++){
		for(int j=0;j<nRow;j++){
			input>>data[i][j].Luong;
			input>>data[i][j].Luong;
			input.getline(data[i][j].HoTen,MAX);
			input.getline(data[i][j].QueQuan,MAX);
		}
	}
	input.close();
}
void FreeData(NhanVien ** &data, int &nCol, int &nRow){
	for(int i = 0; i < nRow ;i++){
		delete data[i];
	}
	delete []data;
}
void PrintData(NhanVien **data, int &nCol, int &nRow){
	for(int i=0;i<nCol;i++){
		for(int j=0;j<nRow;j++){
			cout<<data[i][j].HoTen;
			cout<<data[i][j].NamSinh;
			cout<<data[i][j].QueQuan;
			cout<<data[i][j].Luong;
			
		}
		cout<<endl;
	}
}
void PrintNhanVienLonTuoiNhat(NhanVien **data, int nCol, int nRow){
	int min = INT_MAX;
	for(int i = 0; i<nCol; i++){
		for(int j=0;j<nRow;j++){
			min = (min < data[i][j].NamSinh ? min : data[i][j].NamSinh);
		}
	}
}
int main(){
	srand(53194);
	char *path = "data.txt";
	NhanVien** data = NULL;
	int nRow = 7; int nCol=3;
	Load(path, data, nCol, nRow);
	PrintData(data, nCol, nRow);
	cout<<endl;
	PrintNhanVienLonTuoiNhat(data, nCol, nRow);
	///xuat ra man hinh cac nhan vien lon tuoi nhat
	///can thong tin vi tri cua nhan vien
	PrintNhanVienLonTuoiNhat(data, nCol, nRow);
	FreeData(data, nCol, nRow);
	return 0;
}